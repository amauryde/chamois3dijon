<?php
//CONNEXION À LA BDD : CONSTANTES VIDES PAR DEFAUT!
define("db_host", "localhost");
define("db_login", "test");
define("db_password", "test");
define("db_name", "test");

//ESPACE DISQUE / NB USERS / SALT
define("limite_espace_disque", "10737418240");
define("limite_nb_users", "10000");
define("AGORA_SALT", "");

