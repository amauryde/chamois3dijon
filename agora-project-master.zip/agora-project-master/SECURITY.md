# Security Policy

## Reporting a Vulnerability

https://www.agora-project.net -> Forum  -> Send a private message


